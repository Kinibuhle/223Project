﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/***** TT MMOLA 37629905, TB MOTSIRI 29998360, H MALULEKE 38549654, BJ KHALI 42579759 ****/
/***** T GEZANI 32489676, M CINDI 30773954 & Z MAKWARELA   ****/
namespace Project1
{
    public partial class Cart : Form
    {
        // Static list to store cart items across different forms
        public static List<string> CartItems = new List<string>();

        public Cart()
        {
            InitializeComponent();

        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            // Pass the cart items to the Receipt form
            Receipt newMDIChild = new Receipt(CartItems);
            newMDIChild.Show();
        }

        // Method to update the ListBox with the items from the CartItems list
        public void UpdateCartItems()
        {
            lst_Cart.Items.Clear(); // Clear the listbox before populating it

            // Display all items stored in the shared CartItems list
            foreach (var item in CartItems)
            {
                lst_Cart.Items.Add(item);
            }
        }

        private void Cart_Load(object sender, EventArgs e)
        {
            // Call the method to update the cart when the form loads
            UpdateCartItems();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ShowForm<Food>();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ShowForm<Drinks>();
        }

        private void ShowForm<T>() where T : Form, new()
        {
            foreach (Form form in Application.OpenForms)
            {
                if (form.GetType() == typeof(T))
                {
                    form.Activate();
                    return;
                }
            }
            new T().Show();
        }
    }
}
